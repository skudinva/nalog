import { getRandomArrayElement } from './utils';

const pictureState = {
  pictures: null,
  selectedPicture: null,
  lastCommentShowItem: -1,
  selectedFilter: null,
};

const defaultPictureState = { ...pictureState };

const getPictures = function () {
  const currentFilter = pictureState.selectedFilter.id;

  if (currentFilter === 'filter-default') {
    return pictureState.pictures;
  } else if (currentFilter === 'filter-random') {
    return Array.from({ length: 10 }, () =>
      getRandomArrayElement(pictureState.pictures)
    );
  } else if (currentFilter === 'filter-discussed') {
    console.log(
      pictureState.pictures.sort(
        (a, b) => a.comments.length >= b.comments.length
      )
    );
  }

  /*
  similarWizards
  .slice()
  .sort(compareWizards)
  .slice(0, SIMILAR_WIZARD_COUNT)
  .forEach(({name, colorCoat, colorEyes}) => {
    const wizardElement = similarWizardTemplate.cloneNode(true);
    wizardElement.querySelector('.setup-similar-label').textContent = name;
    wizardElement.querySelector('.wizard-coat').style.fill = colorCoat;
    wizardElement.querySelector('.wizard-eyes').style.fill = colorEyes;
    similarListFragment.appendChild(wizardElement);
  });
*/
  return pictureState.pictures;
};

const setPictures = function (value) {
  pictureState.pictures = value;
};

const getPictureById = function (pictureId) {
  return pictureState.pictures.find((element) => element.id === pictureId);
};

const getSelectedPicture = function () {
  return pictureState.selectedPicture;
};

const setSelectedPicture = function (pictureId) {
  pictureState.selectedPicture = getPictureById(pictureId);
};

const resetSelectedPicture = function () {
  pictureState.selectedPicture = defaultPictureState.selectedPicture;
  pictureState.lastCommentShowItem = defaultPictureState.lastCommentShowItem;
};

const getComments = function () {
  return pictureState.selectedPicture.comments;
};

const getLastCommentShowItem = function () {
  return pictureState.lastCommentShowItem;
};

const setLastCommentShowItem = function (value) {
  pictureState.lastCommentShowItem = value;
};

const getSelectedFilter = function () {
  return pictureState.selectedFilter;
};

const setSelectedFilter = function (value) {
  pictureState.selectedFilter = value;
};

export {
  getComments,
  getLastCommentShowItem,
  getPictures,
  getSelectedFilter,
  getSelectedPicture,
  resetSelectedPicture,
  setLastCommentShowItem,
  setPictures,
  setSelectedFilter,
  setSelectedPicture,
};
