export const postConfig = {
  commentId: 1,
  likes: {
    min: 15,
    max: 200
  },
  avatars: {
    min: 1,
    max: 6
  }
};
