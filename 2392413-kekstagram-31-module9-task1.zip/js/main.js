import { drawThumbnails } from "./draw-thumbnails.js";
import { createPosts } from "./posts.js";
import { initUploadPicture } from "./upload-picture.js";

const posts = createPosts(25, 30);
drawThumbnails(posts);
initUploadPicture();
